^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package abb_moveit_plugins
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.1.4 (2014-12-14)
------------------
* No changes

1.1.3 (2014-09-05)
------------------
* Merged changes from hydro (release) branch.  Changes include only release artifacts
* Add deprecation notice to old packages.
  And point users to the replacements.
* Contributors: Shaun Edwards, gavanderhoorn

1.1.2 (2014-06-07)
------------------
* Merge pull request `#36 <https://github.com/ros-industrial/abb/issues/36>`_ from cottsay/moveit_plugins_dep
  moveit_plugins: add depend on tf_conversions
* Contributors: Scott K Logan, Shaun Edwards

1.1.1 (2014-05-27)
------------------
* Updated package versions to match abb meta-package version, in prep for release
* moveit_plugins: add install targets. Fix `#9 <https://github.com/ros-industrial/abb/issues/9>`_.
* moveit_plugins: catkin pkgs are not system depends. Fix `#15 <https://github.com/ros-industrial/abb/issues/15>`_.
* moveit_plugins: add install targets. Fix `#9 <https://github.com/ros-industrial/abb/issues/9>`_.
* moveit_plugins: catkin pkgs are not system depends. Fix `#15 <https://github.com/ros-industrial/abb/issues/15>`_.
* Fix issue`#1 <https://github.com/ros-industrial/abb/issues/1>`_ (modified virtual method signatures in order to match new interface)
* Contributors: JeremyZoss, Shaun Edwards, gavanderhoorn, jrgnicho, shaun-edwards
