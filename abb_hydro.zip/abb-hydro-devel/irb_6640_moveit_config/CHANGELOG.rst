^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package irb_6640_moveit_config
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.1.4 (2014-12-14)
------------------
* No changes

1.1.3 (2014-09-05)
------------------
* Merged changes from hydro (release) branch.  Changes include only release artifacts
* Add deprecation notice to old packages.
  And point users to the replacements.
* Contributors: Shaun Edwards, gavanderhoorn

1.1.2 (2014-06-07)
------------------
* No changes

1.1.1 (2014-05-27)
------------------
* Updated package versions to match abb meta-package version, in prep for release
* Added new files missed in last commit
* Regenerated moveit package for irb 6640
* moveit_cfgs: add GetPlanningScene capability. Fix `#18 <https://github.com/ros-industrial/abb/issues/18>`_.
* moveit_cfgs: run_depend on industrial_robot_simulator. Fix `#16 <https://github.com/ros-industrial/abb/issues/16>`_.
* moveit_cfgs: add GetPlanningScene capability. Fix `#18 <https://github.com/ros-industrial/abb/issues/18>`_.
* moveit_cfgs: run_depend on industrial_robot_simulator. Fix `#16 <https://github.com/ros-industrial/abb/issues/16>`_.
* changed naming link_base into base_link and corrected collision meshes
* Added files for IRB6640
* Contributors: Berend Kupers, Shaun Edwards, gavanderhoorn
