# ABB

[ROS-Industrial][] ABB meta-package.  See the [ROS wiki][] page for more information.  

## Contents

This repo holds source code for all versions > groovy. For those versions <= groovy see: [SVN repo][]

[ROS-Industrial]: http://www.ros.org/wiki/Industrial
[ROS wiki]: http://ros.org/wiki/abb
[SVN repo]: https://code.google.com/p/swri-ros-pkg/source/browse
