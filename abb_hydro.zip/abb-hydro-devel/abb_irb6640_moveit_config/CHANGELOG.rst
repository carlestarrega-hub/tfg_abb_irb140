^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package abb_irb6640_moveit_config
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.1.4 (2014-12-14)
------------------
* No changes

1.1.3 (2014-09-05)
------------------
* Bump versions.
* irb6640: (re)add plan execution support to MoveIt package.
* irb6640: add basic (regenerated) MoveIt package.
  Regenerated package, updated version of the irb_6640_moveit_config.
  This uses the files from the abb_irb6600_support package.
* Contributors: gavanderhoorn
