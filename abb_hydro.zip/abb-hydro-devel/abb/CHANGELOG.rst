^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package abb
^^^^^^^^^^^^^^^^^^^^^^^^^

1.1.4 (2014-12-14)
------------------
* Merged release artifacts from hydro branch
* meta: update description.
* Contributors: Shaun Edwards, gavanderhoorn

1.1.3 (2014-09-05)
------------------
* Merged changes from hydro (release) branch.  Changes include only release artifacts
* meta: add IRB 2400 & 6640 MoveIt configs and plugin pkgs.
* meta: add new IRB support packages (2400, 5400 & 6600).
* driver: move driver (Rapid and nodes) into separate package.
  Node sources, headers and launch files copied from abb_common.
* Contributors: Shaun Edwards, gavanderhoorn

1.1.2 (2014-06-07)
------------------
* No changes

1.1.1 (2014-05-27)
------------------
* Updated abb packages to Catkin
* Fixed minor issues with MoveIt configurations (updates from groovy to hydro)
* Removed arm navigation
* added metapackage subdirectory
  git-svn-id: https://swri-ros-pkg.googlecode.com/svn/branches/catkin_migration@1411 076cdf4d-ed99-c8c1-5d01-9bc0d27e81bd
* Contributors: Shaun Edwards, jrgnicho
