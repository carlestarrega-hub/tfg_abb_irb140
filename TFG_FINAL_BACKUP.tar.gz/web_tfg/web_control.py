#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from std_msgs.msg import String, Float64MultiArray
from moveit_msgs.action import MoveGroup
from rclpy.action import ActionClient
from moveit_msgs.msg import JointConstraint

# --- CONFIGURACIÓN AJUSTADA A UR5E ---
PLANNING_GROUP = 'ur_manipulator' 
# Nombres de juntas del UR5e
JOINT_NAMES = ['shoulder_pan_joint', 'shoulder_lift_joint', 'elbow_joint', 
               'wrist_1_joint', 'wrist_2_joint', 'wrist_3_joint'] 

class RobotControlNode(Node):
    def __init__(self):
        super().__init__('robot_control_node')
        self.get_logger().info("Robot Control Node (ROS 2) iniciado.")
        
        self.action_client = ActionClient(self, MoveGroup, 'move_action')
        
        self.sub_web_cmd = self.create_subscription(String, '/web_commands', self.home_command_callback, 10)
        self.sub_joint_cmd = self.create_subscription(Float64MultiArray, '/joint_commands', self.joint_command_callback, 10)

    def home_command_callback(self, msg):
        if msg.data == "GO_HOME":
            self.get_logger().info("🏠 Orden de ir a HOME recibida.")
            # Posición home para UR5e
            self.mover_a_ejes([0.0, -1.57, 0.0, -1.57, 0.0, 0.0])

    def joint_command_callback(self, msg):
        joint_goals = list(msg.data)
        self.get_logger().info(f"📤 Orden de movimiento: {joint_goals}")
        self.mover_a_ejes(joint_goals)

    def mover_a_ejes(self, joint_values):
        if not self.action_client.wait_for_server(timeout_sec=5.0):
            self.get_logger().error("⚠️ Servidor MoveGroup no disponible. ¿Están corriendo los nodos de MoveIt 2?")
            return

        goal_msg = MoveGroup.Goal()
        goal_msg.request.group_name = PLANNING_GROUP
        
        joint_constraints = []
        for name, value in zip(JOINT_NAMES, joint_values):
            jc = JointConstraint()
            jc.joint_name = name
            jc.position = value
            jc.tolerance_above = 0.05 
            jc.tolerance_below = 0.05
            jc.weight = 1.0
            joint_constraints.append(jc)

        goal_msg.request.goal_constraints.append(MoveGroup.Goal.Constraints(
            joint_constraints=joint_constraints
        ))
        
        self.get_logger().info("⏳ Enviando plan de movimiento...")
        self.action_client.send_goal_async(goal_msg)
        self.get_logger().info("✅ Orden enviada.")


def main(args=None):
    rclpy.init(args=args)
    robot_control_node = RobotControlNode()
    executor = rclpy.executors.MultiThreadedExecutor()
    executor.add_node(robot_control_node)
    
    try:
        executor.spin()
    except KeyboardInterrupt:
        pass
    finally:
        robot_control_node.get_logger().info('Apagando nodo de control...')
        robot_control_node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
