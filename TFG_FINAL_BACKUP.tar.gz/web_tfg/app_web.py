import flask
from flask import Flask, render_template

app = Flask(__name__)

# Ruta principal: Carga tu página de control
@app.route('/')
def index():
    return render_template('monitor.html')

if __name__ == '__main__':
    # '0.0.0.0' permite que entres desde tu PC o móvil
    app.run(host='0.0.0.0', port=8080)
