#!/usr/bin/env python3
import rospy
import time
# Solo usamos mensajes estándar que SÍ tienes instalados
from std_msgs.msg import String, Float64MultiArray

def simular_movimiento(joint_goals):
    print("\n" + "-"*40)
    rospy.loginfo(f"📩 COMANDO RECIBIDO: {joint_goals}")
    print("🤖  ESTADO: Moviendo robot (SIMULACIÓN)...")
    
    # Barra de carga "manual" simple que no requiere instalar nada
    print("    [", end="", flush=True)
    for _ in range(20):
        time.sleep(0.1) # Simulamos tiempo de movimiento (2 segundos)
        print("#", end="", flush=True)
    print("] 100%")
    
    print("✅  ESTADO: Posición alcanzada.")
    print("-" * 40 + "\n")

def home_command_callback(msg):
    if msg.data == "GO_HOME":
        print("\n🏠 ORDEN: Ir a CASA (Home)")
        simular_movimiento([0.0, 0.0, 0.0, 0.0, 0.0, 0.0])

def joint_command_callback(multiarray_msg):
    # Convertimos los datos a lista
    joint_goals = list(multiarray_msg.data)
    simular_movimiento(joint_goals)

def listener():
    # Iniciamos el nodo
    rospy.init_node('web_command_listener', anonymous=True)
    
    print("\n" + "="*50)
    print("   ✅ SISTEMA WEB LISTO (MODO SIMULACIÓN)")
    print("   El robot físico NO se moverá.")
    print("   La web enviará órdenes y aquí las verás.")
    print("="*50 + "\n")
    
    # Nos suscribimos a los temas de la web
    rospy.Subscriber('/web_commands', String, home_command_callback)
    rospy.Subscriber('/joint_commands', Float64MultiArray, joint_command_callback)
    
    # Mantenemos el programa abierto
    rospy.spin()

if __name__ == '__main__':
    try:
        listener()
    except rospy.ROSInterruptException:
        pass
