from setuptools import setup

package_name = 'robot_control_pkg'

setup(
    name=package_name,
    version='1.0.0',
    packages=[package_name],
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='ubuntu',
    maintainer_email='user@todo.todo',
    description='ROS 2 control interface for the web TFG project.',
    license='TODO',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            # Vincula el comando 'ros2 run robot_control_pkg robot_control_node' a tu script
            'robot_control_node = robot_control_pkg.web_control:main',
        ],
    },
)
