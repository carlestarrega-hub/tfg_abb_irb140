## Status

The Gazebo support packages in this repository are unmaintained.

They have not been updated since they were created (mostly in ROS Kinetic and/or Melodic) and their current status is unclear.

They will not be released (anymore), but can be built from source in a Catkin workspace.
