# abb_irb7600_support

## Overview

This package is part of the [ROS-Industrial][] program. See the main [abb][]
page on the ROS wiki for more information on usage.

## Supported Variants

- IRB 7600-150/3.5

[ROS-Industrial]: http://wiki.ros.org/Industrial
[abb]: http://wiki.ros.org/abb
