## Status

The MoveIt configuration packages in this repository are unmaintained.

They have not been updated since they were generated (mostly by the MoveIt Setup Assistant in ROS Kinetic and/or Melodic) and their status is unclear.

They will not be released (anymore), but can be built from source in a Catkin workspace.
